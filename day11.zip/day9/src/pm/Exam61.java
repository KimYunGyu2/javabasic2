package pm;

public class Exam61 {

	public static void main(String[] args) {
/* Interface 인터페이스
 일반적인 인터페이스의 의미를 생각해 보면 입출력 방식의 호환성을 의미한다.
 예를 들면, 컴퓨터에서 usb프린터, usb마우스, usb키보드 ....
 주변기기의 종류와는 상관없이 usb 주변기기면 컴에 꼽기만 하면 제품을 작동시킬수 있다.
 
 일단 자바에서의 인터페이스의 구조....
 
 interface 이름 {
 
 }
 
 
 클래스는 1개 이상의 인터페이스를 구현할 수 있다.
 클래스는 1개 이상의 클래스를 상속 받을수는 없다.

 */

	}

}





