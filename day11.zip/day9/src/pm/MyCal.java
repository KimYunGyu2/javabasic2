package pm;

public class MyCal implements Calculator {

	@Override
	public int plus(int i, int j) {
		// TODO Auto-generated method stub
		return i + j;
	}

	@Override
	public int multiple(int i, int j) {
		// TODO Auto-generated method stub
		return i * j;
	}

}
