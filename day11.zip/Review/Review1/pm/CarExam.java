package pm;

public class CarExam {
    public static void main(String[] args) {
        Car c1 = new Car("소방차");
        Car c2 = new Car();
    }
}
